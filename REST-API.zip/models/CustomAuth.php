<?php


namespace app\models;


use yii\filters\auth\AuthMethod;

class CustomAuth extends AuthMethod
{
    /**
     * @inheritdoc
     */
    public function authenticate($user, $request, $response)
    {
        $headers=getallheaders ();
        if($headers['Authorization']=="bearer XhqQHvWkiQO2pRu1b48Zr4b_5CqnHwva")
            return true;
        return null;
    }
}